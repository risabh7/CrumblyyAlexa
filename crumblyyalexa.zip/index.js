'use strict';
const Alexa = require('alexa-sdk');
var i=0;
exports.handler = function (event, context, callback) {
    try {
        var j;
        var technologyArr = [];
        var BrainyArr = [];
        var LifeTipsArr = [];
        var HealthFitnessArr = [];
        var ExtrasArr = [];
        var content;
        var SurvivalArr = [];
        var PartyArr = [];
        var FoodDrinksArr = [];
        var MoneySaversArr = [];
        var DailylifeArr = [];
        var RelationshipArr = [];
        var fs = require('fs');
        fs.readFile('data.json', "UTF-8", function read(err, data) {
            if (err) {
                throw err;
            }
            else
                content = JSON.parse(data);
            for (j = 0; j < content.length; j++) {
                if ((content[j].category) == "Technology Tricks") {
                    technologyArr.push(content[j]);
                }
                else if ((content[j].category) == "Brainy") {
                    BrainyArr.push(content[j]);
                }
                else if ((content[j].category) == "Life Tips") {
                    LifeTipsArr.push(content[j]);
                }
                else if ((content[j].category) == "Health & Fitness") {
                    HealthFitnessArr.push(content[j]);
                }
                else if ((content[j].category) == "Extras") {
                    ExtrasArr.push(content[j]);
                }
                else if ((content[j].category) == "Survival") {
                    SurvivalArr.push(content[j]);
                }
                else if ((content[j].category) == "Money Savers") {
                    MoneySaversArr.push(content[j]);
                }
                else if ((content[j].category) == "Food & Drinks") {
                    FoodDrinksArr.push(content[j]);
                }
                else if ((content[j].category) == "Daily-life Solutions") {
                    DailylifeArr.push(content[j]);
                }
                else if ((content[j].category) == "Relationship") {
                    RelationshipArr.push(content[j]);
                }
                else if ((content[j].category) == "Party Hacks") {
                    PartyArr.push(content[j]);
                }
            }
            const handlers = {
                'LaunchRequest': function () {
                    var speechOutput = "Welcome to Life hacks by Crumblyy";
                    this.response.speak(speechOutput);
                    this.emit(":responseReady");
                },
                'hackofthedayintent': function () {
                    var request = require('request');
                    var a;
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    request.post(
                        'https://google-actions-crumblyy-jr4llwc645st.runkit.sh/hackOfTheDay',
                        { json: { key: 'value' } },
                        function (error, responseR, body) {
                            if (!error && responseR.statusCode == 200) {
                                a = body.fulfillmentText
                                var img = { imgurl: `${body.fulfillmentMessages[0].card.imageUri}` }
                                var imgAddress = img.imgurl;
                                var fillerTextContent = { title: `${body.fulfillmentMessages[0].card.title}` }
                                var template = bodyTemplate2.setTitle("Crumblyy")
                                    .setTextContent(makePlainText(fillerTextContent.title))
                                    .setImage(makeImage(imgAddress))
                                    .build();
                                response.speak(`${fillerTextContent.title} hack : ${a}`)
                                    .renderTemplate(template)
                                    .shouldEndSession(null);
                                emit(":responseReady");

                            }
                        }
                    );
                },
                'healthintent': function () {
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${HealthFitnessArr[i].category}`))
                        .build();
                    response.speak(`${HealthFitnessArr[i].category} : ${HealthFitnessArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'nexthealthintent': function () {
                    i++;
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${HealthFitnessArr[i].category}`))
                        .build();
                    response.speak(`${HealthFitnessArr[i].category} : ${HealthFitnessArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'previoushealthintent': function () {
                    i--;
                    if (i >= 0) {
                        var response = this.response;
                        var emit = this.emit;
                        const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                        const makeImage = Alexa.utils.ImageUtils.makeImage;
                        const makePlainText = Alexa.utils.TextUtils.makePlainText;
                        var template = bodyTemplate2.setTitle("Crumblyy")
                            .setTextContent(makePlainText(`${HealthFitnessArr[i].category}`))
                            .build();
                        response.speak(`${HealthFitnessArr[i].category} : ${HealthFitnessArr[i].body}`)
                            .renderTemplate(template)
                            .shouldEndSession(null);
                        emit(":responseReady");
                    }
                },
                'technologyintent': function () {
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${technologyArr[i].category}`))
                        .build();
                    response.speak(`${technologyArr[i].category} : ${technologyArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'nexttechnologyintent': function () {
                    i++;
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${technologyArr[i].category}`))
                        .build();
                    response.speak(`${technologyArr[i].category} : ${technologyArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'previoustechnologyintent': function () {
                    i--;
                    if (i >= 0) {
                        var response = this.response;
                        var emit = this.emit;
                        const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                        const makeImage = Alexa.utils.ImageUtils.makeImage;
                        const makePlainText = Alexa.utils.TextUtils.makePlainText;
                        var template = bodyTemplate2.setTitle("Crumblyy")
                            .setTextContent(makePlainText(`${technologyArr[i].category}`))
                            .build();
                        response.speak(`${technologyArr[i].category} : ${technologyArr[i].body}`)
                            .renderTemplate(template)
                            .shouldEndSession(null);
                        emit(":responseReady");
                    }
                },
                'relationshipintent': function () {
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${RelationshipArr[i].category}`))
                        .build();
                    response.speak(`${RelationshipArr[i].category} : ${RelationshipArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'nextrelationshipintent': function () {
                    i++;
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${RelationshipArr[i].category}`))
                        .build();
                    response.speak(`${RelationshipArr[i].category} : ${RelationshipArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'previousrelationshipintent': function () {
                    i--;
                    if (i >= 0) {
                        var response = this.response;
                        var emit = this.emit;
                        const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                        const makeImage = Alexa.utils.ImageUtils.makeImage;
                        const makePlainText = Alexa.utils.TextUtils.makePlainText;
                        var template = bodyTemplate2.setTitle("Crumblyy")
                            .setTextContent(makePlainText(`${RelationshipArr[i].category}`))
                            .build();
                        response.speak(`${RelationshipArr[i].category} : ${RelationshipArr[i].body}`)
                            .renderTemplate(template)
                            .shouldEndSession(null);
                        emit(":responseReady");
                    }
                },
                'partyintent': function () {
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${PartyArr[i].category}`))
                        .build();
                    response.speak(`${PartyArr[i].category} : ${PartyArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'nextpartyintent': function () {
                    i++;
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${PartyArr[i].category}`))
                        .build();
                    response.speak(`${PartyArr[i].category} : ${PartyArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'previouspartyintent': function () {
                    i--;
                    if (i >= 0) {
                        var response = this.response;
                        var emit = this.emit;
                        const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                        const makeImage = Alexa.utils.ImageUtils.makeImage;
                        const makePlainText = Alexa.utils.TextUtils.makePlainText;
                        var template = bodyTemplate2.setTitle("Crumblyy")
                            .setTextContent(makePlainText(`${PartyArr[i].category}`))
                            .build();
                        response.speak(`${PartyArr[i].category} : ${PartyArr[i].body}`)
                            .renderTemplate(template)
                            .shouldEndSession(null);
                        emit(":responseReady");
                    }
                },
                'dailylifeintent': function () {
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${DailylifeArr[i].category}`))
                        .build();
                    response.speak(`${DailylifeArr[i].category} : ${DailylifeArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'nextdailylifeintent': function () {
                    i++;
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${DailylifeArr[i].category}`))
                        .build();
                    response.speak(`${DailylifeArr[i].category} : ${DailylifeArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'previousdailylifeintent': function () {
                    i--;
                    if (i >= 0) {
                        if (i >= 0)
                            var response = this.response;
                        var emit = this.emit;
                        const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                        const makeImage = Alexa.utils.ImageUtils.makeImage;
                        const makePlainText = Alexa.utils.TextUtils.makePlainText;
                        var template = bodyTemplate2.setTitle("Crumblyy")
                            .setTextContent(makePlainText(`${DailylifeArr[i].category}`))
                            .build();
                        response.speak(`${DailylifeArr[i].category} : ${DailylifeArr[i].body}`)
                            .renderTemplate(template)
                            .shouldEndSession(null);
                        emit(":responseReady");
                    }
                },
                'fooddrinksintent': function () {
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${FoodDrinksArr[i].category}`))
                        .build();
                    response.speak(`${FoodDrinksArr[i].category} : ${FoodDrinksArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'nextfooddrinksintent': function () {
                    i++;
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${FoodDrinksArr[i].category}`))
                        .build();
                    response.speak(`${FoodDrinksArr[i].category} : ${FoodDrinksArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'previousfooddrinksintent': function () {
                    i--;
                    if (i >= 0) {
                        if (i >= 0)
                            var response = this.response;
                        var emit = this.emit;
                        const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                        const makeImage = Alexa.utils.ImageUtils.makeImage;
                        const makePlainText = Alexa.utils.TextUtils.makePlainText;
                        var template = bodyTemplate2.setTitle("Crumblyy")
                            .setTextContent(makePlainText(`${FoodDrinksArr[i].category}`))
                            .build();
                        response.speak(`${FoodDrinksArr[i].category} : ${FoodDrinksArr[i].body}`)
                            .renderTemplate(template)
                            .shouldEndSession(null);
                        emit(":responseReady");
                    }
                },
                'moneysaverintent': function () {
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${MoneySaversArr[i].category}`))
                        .build();
                    response.speak(`${MoneySaversArr[i].category} : ${MoneySaversArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'nextmoneysaverintent': function () {
                    i++;
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${MoneySaversArr[i].category}`))
                        .build();
                    response.speak(`${MoneySaversArr[i].category} : ${MoneySaversArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'previousmoneysaverintent': function () {
                    i--;
                    if (i >= 0) {
                        if (i >= 0)
                            var response = this.response;
                        var emit = this.emit;
                        const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                        const makeImage = Alexa.utils.ImageUtils.makeImage;
                        const makePlainText = Alexa.utils.TextUtils.makePlainText;
                        var template = bodyTemplate2.setTitle("Crumblyy")
                            .setTextContent(makePlainText(`${MoneySaversArr[i].category}`))
                            .build();
                        response.speak(`${MoneySaversArr[i].category} : ${MoneySaversArr[i].body}`)
                            .renderTemplate(template)
                            .shouldEndSession(null);
                        emit(":responseReady");
                    }
                },
                'survivalintent': function () {
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${SurvivalArr[i].category}`))
                        .build();
                    response.speak(`${SurvivalArr[i].category} : ${SurvivalArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'nextsurvivalintent': function () {
                    i++;
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${SurvivalArr[i].category}`))
                        .build();
                    response.speak(`${SurvivalArr[i].category} : ${SurvivalArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'previoussurvivalintent': function () {
                    i--;
                    if (i >= 0) {
                        if (i >= 0)
                            var response = this.response;
                        var emit = this.emit;
                        const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                        const makeImage = Alexa.utils.ImageUtils.makeImage;
                        const makePlainText = Alexa.utils.TextUtils.makePlainText;
                        var template = bodyTemplate2.setTitle("Crumblyy")
                            .setTextContent(makePlainText(`${SurvivalArr[i].category}`))
                            .build();
                        response.speak(`${SurvivalArr[i].category} : ${SurvivalArr[i].body}`)
                            .renderTemplate(template)
                            .shouldEndSession(null);
                        emit(":responseReady");
                    }
                },
                'extrasintent': function () {
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${ExtrasArr[i].category}`))
                        .build();
                    response.speak(`${ExtrasArr[i].category} : ${ExtrasArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'nextextrasintent': function () {
                    i++;
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${ExtrasArr[i].category}`))
                        .build();
                    response.speak(`${ExtrasArr[i].category} : ${ExtrasArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'previousextrasintent': function () {
                    i--;
                    if (i >= 0) {
                        if (i >= 0)
                            var response = this.response;
                        var emit = this.emit;
                        const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                        const makeImage = Alexa.utils.ImageUtils.makeImage;
                        const makePlainText = Alexa.utils.TextUtils.makePlainText;
                        var template = bodyTemplate2.setTitle("Crumblyy")
                            .setTextContent(makePlainText(`${ExtrasArr[i].category}`))
                            .build();
                        response.speak(`${ExtrasArr[i].category} : ${ExtrasArr[i].body}`)
                            .renderTemplate(template)
                            .shouldEndSession(null);
                        emit(":responseReady");
                    }
                },
                'brainyintent': function () {
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${BrainyArr[i].category}`))
                        .build();
                    response.speak(`${BrainyArr[i].category} : ${BrainyArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'nextbrainyintent': function () {
                    i++;
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${BrainyArr[i].category}`))
                        .build();
                    response.speak(`${BrainyArr[i].category} : ${BrainyArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'previousbrainyintent': function () {
                    i--;
                    if (i >= 0) {
                        if (i >= 0)
                            var response = this.response;
                        var emit = this.emit;
                        const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                        const makeImage = Alexa.utils.ImageUtils.makeImage;
                        const makePlainText = Alexa.utils.TextUtils.makePlainText;
                        var template = bodyTemplate2.setTitle("Crumblyy")
                            .setTextContent(makePlainText(`${BrainyArr[i].category}`))
                            .build();
                        response.speak(`${BrainyArr[i].category} : ${BrainyArr[i].body}`)
                            .renderTemplate(template)
                            .shouldEndSession(null);
                        emit(":responseReady");
                    }
                },
                'lifetipsintent': function () {
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${LifeTipsArr[i].category}`))
                        .build();
                    response.speak(`${LifeTipsArr[i].category} : ${LifeTipsArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'nextlifetipsintent': function () {
                    i++;
                    var response = this.response;
                    var emit = this.emit;
                    const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                    const makeImage = Alexa.utils.ImageUtils.makeImage;
                    const makePlainText = Alexa.utils.TextUtils.makePlainText;
                    var template = bodyTemplate2.setTitle("Crumblyy")
                        .setTextContent(makePlainText(`${LifeTipsArr[i].category}`))
                        .build();
                    response.speak(`${LifeTipsArr[i].category} : ${LifeTipsArr[i].body}`)
                        .renderTemplate(template)
                        .shouldEndSession(null);
                    emit(":responseReady");
                },
                'previouslifetipsintent': function () {
                    i--;
                    if (i >= 0) {
                        if (i >= 0)
                            var response = this.response;
                        var emit = this.emit;
                        const bodyTemplate2 = new Alexa.templateBuilders.BodyTemplate2Builder();
                        const makeImage = Alexa.utils.ImageUtils.makeImage;
                        const makePlainText = Alexa.utils.TextUtils.makePlainText;
                        var template = bodyTemplate2.setTitle("Crumblyy")
                            .setTextContent(makePlainText(`${LifeTipsArr[i].category}`))
                            .build();
                        response.speak(`${LifeTipsArr[i].category} : ${LifeTipsArr[i].body}`)
                            .renderTemplate(template)
                            .shouldEndSession(null);
                        emit(":responseReady");
                    }
                },
            };
            const alexa = Alexa.handler(event, context, callback);
            // To enable string internationalization (i18n) features, set a resources object.
            alexa.registerHandlers(handlers);
            alexa.execute();
            function supportsDisplay() {
                var hasDisplay =
                    this.event.context &&
                    this.event.context.System &&
                    this.event.context.System.device &&
                    this.event.context.System.device.supportedInterfaces &&
                    this.event.context.System.device.supportedInterfaces.Display

                return hasDisplay;
            }
        });

    } catch (error) {
        context.fail('Exception:${error}')
    }
    //context.done(null, '');
};